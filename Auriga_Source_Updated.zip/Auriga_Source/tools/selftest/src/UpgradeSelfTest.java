import com.vrksignatures.sudhaautobot.RetailerPolicy;
import com.vrksignatures.sudhaautobot.RetailerSequence;
import com.vrksignatures.sudhaautobot.ScrollMemory;
import com.vrksignatures.sudhaautobot.StartPoint;
import com.vrksignatures.sudhaautobot.UpgradeRules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * End-to-end JVM verification of ALL upgraded behaviors, including the exact screen recording
 * scenario (SMR2157 typed as Last done ID -> next card 20173 Abhishek Enterprises -> 19863 -> 19824).
 */
public final class UpgradeSelfTest {

    private static int checks;

    private static void check(boolean cond, String msg) {
        checks++;
        if (!cond) throw new AssertionError("FAIL: " + msg);
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== UpgradeSelfTest ==");

        // 1. Arbitrary Customer IDs accepted verbatim
        check(RetailerPolicy.isValidCustomerId("20173"), "numeric 20173 valid");
        check(RetailerPolicy.isValidCustomerId("19863"), "numeric 19863 valid");
        check(RetailerPolicy.isValidCustomerId("ABCD"), "alphabetic ABCD valid");
        check(RetailerPolicy.isValidCustomerId("ABC-17"), "hyphenated ABC-17 valid");
        check(RetailerPolicy.isValidCustomerId("R 204"), "spaced R 204 valid");
        check(RetailerPolicy.isValidCustomerId("SMR2157"), "SMR2157 valid");
        check(!RetailerPolicy.isValidCustomerId("   "), "blank rejected");
        check("20173".equals(RetailerPolicy.normalizeAnyId(" 20173 ")), "20173 stays 20173, never SMR20173");
        check("ABC-17".equals(RetailerPolicy.normalizeAnyId(" abc-17 ")), "ABC-17 preserved");

        // 2. EXACT VIDEO SCENARIO (00:57): SMR2157 typed in Last done ID, 20173 right below it!
        List<String> videoScreen = Arrays.asList("SMR2160", "SMR2159", "SMR2158", "SMR2157", "20173");
        Set<String> done = new LinkedHashSet<>();
        StartPoint.Seeker seeker = new StartPoint.Seeker("SMR2157", "typed on the panel");
        StartPoint.Book book = new StartPoint.Book() {
            @Override public boolean isProcessed(String id) { return done.contains(id); }
            @Override public String lastHandled() { return "SMR2157"; }
            @Override public boolean markDoneBefore(String id, String why) { return done.add(id); }
        };
        StartPoint.Seeker.Outcome seekOut = seeker.seesAnyId(videoScreen, book);
        check(seekOut == StartPoint.Seeker.Outcome.REACHED, "Seeker reaches SMR2157 immediately on video screen");
        check(done.contains("SMR2157") && !done.contains("20173"), "SMR2157 marked done, 20173 NOT marked done");

        RetailerSequence seq = new RetailerSequence();
        RetailerSequence.Decision nextAfter2157 = seq.decideAnyId(videoScreen, "SMR2157", done::contains);
        check(nextAfter2157.action == RetailerSequence.Action.OPEN && "20173".equals(nextAfter2157.id),
                "Video scenario: MUST open 20173 (Abhishek Enterprises) immediately after SMR2157!");

        // Next page with ONLY numeric IDs (19863, 19824, 19823, 19821)
        List<String> numericPage = Arrays.asList("19863", "19824", "19823", "19821");
        done.add("20173");
        RetailerSequence.Decision nextNumeric = seq.decideAnyId(numericPage, "20173", done::contains);
        check(nextNumeric.action == RetailerSequence.Action.OPEN && "19863".equals(nextNumeric.id),
                "Numeric page: MUST open 19863 right after 20173!");

        // 3. ScrollMemory.nextAnyId on pure numeric-ID page (must NOT falsely declare FURTHER_DOWN)
        ScrollMemory.Seek smSeek = new ScrollMemory.Seek("20173", 5);
        smSeek.burst();
        ScrollMemory.Move mv = smSeek.nextAnyId(numericPage, done::contains, "19863@100;19824@200;");
        check(mv == ScrollMemory.Move.BACK, "ScrollMemory sees unhandled numeric IDs and looks UP (not FURTHER_DOWN)");

        // 4. Same-page Ranjana Dist SM65 + adjacent Retailer 65 skipped; Mushkan Kirana is True Retailer #1
        List<UpgradeRules.Card> list1 = Arrays.asList(
                new UpgradeRules.Card("SM65", "RANJANA YADVENDU", true, false),
                new UpgradeRules.Card("65", "RANJANA YADVENDU", false, true),
                new UpgradeRules.Card("SMR2255", "MUSHKAN KIRANA", false, true),
                new UpgradeRules.Card("1234", "OM KIRANA", false, true)
        );
        UpgradeRules.Classification c1 = UpgradeRules.classifyCards(list1);
        check(c1.allBlacklistedIds.contains("SM65") && c1.allBlacklistedIds.contains("65"), "Dist SM65 + shadow 65 blacklisted");
        check(c1.genuineRetailers.size() == 2 && "SMR2255".equals(c1.genuineRetailers.get(0).customerId),
                "SMR2255 is True Retailer #1");

        // 5. Cross-page Dist-to-shadow boundary carry-over
        List<UpgradeRules.Card> page1 = Arrays.asList(
                new UpgradeRules.Card("101", "ALPHA SHOP", false, true),
                new UpgradeRules.Card("SM100", "NORTH DAIRY", true, false)
        );
        UpgradeRules.Classification cp1 = UpgradeRules.classifyCards(page1);
        check("north dairy".equals(cp1.trailingDistributorName), "Page 1 detects trailing Dist at bottom");

        List<UpgradeRules.Card> page2 = Arrays.asList(
                new UpgradeRules.Card("778812", "NORTH DAIRY", false, true),
                new UpgradeRules.Card("ABC-17", "VILLAGE SHOP", false, true),
                new UpgradeRules.Card("9999", "NORTH DAIRY", false, true)
        );
        UpgradeRules.Classification cp2 = UpgradeRules.classifyCardsWithCarryOver(page2, cp1.trailingDistributorName);
        check(cp2.allBlacklistedIds.contains("778812"), "Cross-page immediate shadow 778812 boycotted");
        check(!cp2.allBlacklistedIds.contains("ABC-17") && !cp2.allBlacklistedIds.contains("9999"),
                "Genuine ABC-17 and later same-name 9999 kept");

        // 6. Employee's Chance scatter & Customer Demand pack math
        Map<Integer, Integer> plan = UpgradeRules.generateScatteredPlan("2026-11-20", 10000, 15, 125);
        int sum = 0;
        List<Integer> keys = new ArrayList<>(plan.keySet());
        for (int v : plan.values()) sum += v;
        check(plan.size() == 15 && sum == 10000 && keys.get(keys.size() - 1) > 30, "Scatter plan valid");

        int[] delta = UpgradeRules.resolvePackDelta(1000, 0, 4);
        check(delta != null && delta[0] == 500 && delta[1] == 6, "COW 500 ML 4 -> 6");

        
        // 6. REAL PHONE CAPTURE 1 (2026-11-20 23:55:41) - Split TextView nodes: "Delivery Point" + "(Dist)"/"(Retailer)"
        List<String> capture1Labels = Arrays.asList(
                "Navigate up", "Customers", "Total Customers:", "125", "All Distributors", "Show Retailers",
                "Delivery Point", "(Dist)", "Customer Id:", "SM65", "RANJANA YADVENDU", "Route 65", "7717779677", "S.O(s) :", "ARA_PLANT", "P.R (Id):", "2520749",
                "Delivery Point", "(Retailer)", "Customer Id:", "65", "RANJANA YADVENDU", "RTR_65_AM", "S.O(s) :", "RANJANA YADVENDU[SO]", "P.R (Id):", "2520749",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2255", "MUSHKAN KIRANA", "RTR_65_AM", "9334555196", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2254", "OM KIRANA", "RTR_65_AM", "7492041097", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2253", "SHUBHAM MILK", "RTR_65_AM", "9546290190", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2252", "SHREE SAI KRISHNA", "RTR_65_AM", "7488539947", "S.O(s) :", "RANJANA YADVENDU[SO]"
        );
        List<UpgradeRules.Card> cap1Cards = UpgradeRules.extractCardsFromFlatLabels(capture1Labels);
        check(cap1Cards.size() == 6, "Capture 1 parses all 6 split-node cards");
        UpgradeRules.Classification cap1Cls = UpgradeRules.classifyCards(cap1Cards);
        check(cap1Cls.distributorIds.contains("SM65"), "Capture 1 skips SM65 Dist");
        check(cap1Cls.distributorOwnedRetailerIds.contains("65"), "Capture 1 skips 65 adjacent shadow");
        check(cap1Cls.genuineRetailers.size() == 4, "Capture 1 yields 4 genuine retailers");
        check("SMR2255".equals(cap1Cls.genuineRetailers.get(0).customerId)
                        && "MUSHKAN KIRANA".equals(cap1Cls.genuineRetailers.get(0).boldOrangeName),
                "Capture 1 first genuine is SMR2255 MUSHKAN KIRANA");

        // 7. REAL PHONE CAPTURE 2 (2026-11-20 23:57:11) - SMR2157 -> 20173 -> 19863 -> 19824 + mixed-case Shop Names
        List<String> capture2Labels = Arrays.asList(
                "Total Customers:", "125", "All Distributors", "Show Retailers",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2159", "MOTA BHAI", "RTR_65_AM", "9386121074", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2158", "Sonu Milk Parlor", "RTR_65_AM", "7992337899", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "SMR2157", "PANDEY G SUDHA MILK PARLOR", "RTR_65_AM", "6202750947", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "20173", "Abhishek Enterprises", "RTR_65_AM", "9162851785", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "19863", "Lal ji kirana", "RTR_65_AM", "6200873714", "S.O(s) :", "RANJANA YADVENDU[SO]",
                "Delivery Point", "(Retailer)", "Customer Id:", "19824", "Aditya Kirana", "RTR_65_AM", "9999999999", "S.O(s) :", "RANJANA YADVENDU[SO]"
        );
        List<UpgradeRules.Card> cap2Cards = UpgradeRules.extractCardsFromFlatLabels(capture2Labels);
        check(cap2Cards.size() == 6, "Capture 2 parses all 6 cards");
        check("Sonu Milk Parlor".equals(cap2Cards.get(1).boldOrangeName), "Capture 2 reads Sonu Milk Parlor (not [SO])");
        check("20173".equals(cap2Cards.get(3).customerId) && "Abhishek Enterprises".equals(cap2Cards.get(3).boldOrangeName),
                "Capture 2 reads 20173 Abhishek Enterprises (not [SO])");
        check("19863".equals(cap2Cards.get(4).customerId) && "Lal ji kirana".equals(cap2Cards.get(4).boldOrangeName),
                "Capture 2 reads 19863 Lal ji kirana (not [SO])");
        check("19824".equals(cap2Cards.get(5).customerId) && "Aditya Kirana".equals(cap2Cards.get(5).boldOrangeName),
                "Capture 2 reads 19824 Aditya Kirana (not [SO])");

        // 8. Space-tolerant "SMR 2157" -> immediately picks 20173 -> 19863 -> 19824
        check("SMR2157".equals(RetailerPolicy.normalizeAnyId("SMR 2157")), "normalizeAnyId collapses 'SMR 2157' -> 'SMR2157'");
        check("20173".equals(RetailerPolicy.normalizeAnyId("20173")), "normalizeAnyId keeps '20173' numeric");
        check(RetailerPolicy.sameCustomerId("smr 2157", "SMR2157"), "sameCustomerId matches 'smr 2157' and 'SMR2157'");

        List<String> cap2Ids = new ArrayList<>();
        for (UpgradeRules.Card c : cap2Cards) cap2Ids.add(c.customerId);
        Set<String> cap2Done = new LinkedHashSet<>();
        StartPoint.Seeker spSeeker = new StartPoint.Seeker(RetailerPolicy.normalizeAnyId("SMR 2157"), "typed with space");
        StartPoint.Seeker.Outcome spOut = spSeeker.seesAnyId(cap2Ids, new StartPoint.Book() {
            public boolean isProcessed(String id) { return cap2Done.contains(id); }
            public String lastHandled() { return "SMR2157"; }
            public boolean markDoneBefore(String id, String why) { return cap2Done.add(id); }
        });
        check(spOut == StartPoint.Seeker.Outcome.REACHED, "Seeker reaches SMR2157 from spaced 'SMR 2157'");
        check(cap2Done.contains("SMR2157") && !cap2Done.contains("20173"), "Seeker marks SMR2159/SMR2158/SMR2157 done");

        RetailerSequence cap2Seq = new RetailerSequence();
        RetailerSequence.Decision dCap2_1 = cap2Seq.decideAnyId(cap2Ids, "SMR 2157", cap2Done::contains);
        check(dCap2_1.action == RetailerSequence.Action.OPEN && "20173".equals(dCap2_1.id),
                "After 'SMR 2157', opens 20173 immediately");
        cap2Done.add("20173");
        RetailerSequence.Decision dCap2_2 = cap2Seq.decideAnyId(cap2Ids, "20173", cap2Done::contains);
        check(dCap2_2.action == RetailerSequence.Action.OPEN && "19863".equals(dCap2_2.id),
                "After 20173, opens 19863 immediately");
        cap2Done.add("19863");
        RetailerSequence.Decision dCap2_3 = cap2Seq.decideAnyId(cap2Ids, "19863", cap2Done::contains);
        check(dCap2_3.action == RetailerSequence.Action.OPEN && "19824".equals(dCap2_3.id),
                "After 19863, opens 19824 immediately");

        // 9. Missing Customer ID fallback uses Shop Name key (never drops genuine Retailer card)
        UpgradeRules.Card noIdCard = UpgradeRules.extractCardFromTexts(
                Arrays.asList("Delivery Point", "(Retailer)", "DURGA KIRANA", "RTR_65_AM"));
        check(noIdCard != null && noIdCard.isRetailer && "NAME:DURGA KIRANA".equals(noIdCard.customerId),
                "Missing ID card still parsed by Shop Name");

        // 10. Static source check: DistributorBlueprint uses live cv_parent_view + split (Dist)/(Retailer)
        java.nio.file.Path dbPath = java.nio.file.Paths.get("app/src/main/java/com/vrksignatures/sudhaautobot/DistributorBlueprint.java");
        if (!java.nio.file.Files.exists(dbPath)) {
            dbPath = java.nio.file.Paths.get("../../app/src/main/java/com/vrksignatures/sudhaautobot/DistributorBlueprint.java");
        }
        String dbSrc = new String(java.nio.file.Files.readAllBytes(dbPath));
        check(dbSrc.contains("cv_parent_view"), "DistributorBlueprint parses cv_parent_view");
        check(dbSrc.contains("t.equals(\"(retailer)\")"), "DistributorBlueprint handles split (retailer) node");

        
        // 11. ALL-BOXES + MANUAL BOYCOTT LIST MODE (Zero SMR filtering!)
        Set<String> manualBoycott = UpgradeRules.parseManualBoycottText("SM65, 65\nSM41 ; sm 99");
        check(manualBoycott.size() == 4 && manualBoycott.contains("SM65") && manualBoycott.contains("65")
                && manualBoycott.contains("SM41") && manualBoycott.contains("SM99"),
                "parseManualBoycottText parses comma/newline/semicolon IDs");
        check(UpgradeRules.isBoycotted("sm 65", manualBoycott), "isBoycotted matches space/case variants");
        check(!UpgradeRules.isBoycotted("20173", manualBoycott), "isBoycotted allows non-boycotted numeric ID 20173");

        List<UpgradeRules.Card> cap1Eligible = UpgradeRules.filterOutBoycotted(cap1Cards, manualBoycott);
        check(cap1Eligible.size() == 4 && "SMR2255".equals(cap1Eligible.get(0).customerId),
                "Capture 1 with Boycott 'SM65, 65' skips ONLY SM65 & 65 and opens SMR2255 first");

        List<UpgradeRules.Card> cap1All = UpgradeRules.filterOutBoycotted(cap1Cards, Collections.emptySet());
        check(cap1All.size() == 6 && "SM65".equals(cap1All.get(0).customerId) && "65".equals(cap1All.get(1).customerId),
                "Capture 1 with EMPTY Boycott keeps ALL 6 boxes (zero hardcoded SMR/Dist filter)");

        List<UpgradeRules.Card> cap2Eligible = UpgradeRules.filterOutBoycotted(cap2Cards, manualBoycott);
        check(cap2Eligible.size() == 6 && "20173".equals(cap2Eligible.get(3).customerId)
                && "19863".equals(cap2Eligible.get(4).customerId) && "19824".equals(cap2Eligible.get(5).customerId),
                "Capture 2 keeps all SMR + numeric IDs (SMR2159..19824)");

        // Even a box with NO Delivery Point / (Retailer) label at all is parsed by extractAnyCustomerBox
        UpgradeRules.Card bareBox = UpgradeRules.extractAnyCustomerBox(
                Arrays.asList("Customer Id:", "20173", "Abhishek Enterprises", "RTR_65_AM"));
        check(bareBox != null && "20173".equals(bareBox.customerId) && "Abhishek Enterprises".equals(bareBox.boldOrangeName),
                "extractAnyCustomerBox parses box without Delivery Point label");

        // Static check: MainActivity exposes BOYCOTT / REJECT CUSTOMER IDs UI & Service uses parseAllCustomerBoxes
        java.nio.file.Path maPath = java.nio.file.Paths.get("app/src/main/java/com/vrksignatures/sudhaautobot/MainActivity.java");
        if (!java.nio.file.Files.exists(maPath)) maPath = java.nio.file.Paths.get("../../app/src/main/java/com/vrksignatures/sudhaautobot/MainActivity.java");
        String maSrc = new String(java.nio.file.Files.readAllBytes(maPath));
        check(maSrc.contains("BOYCOTT / REJECT CUSTOMER IDs"), "MainActivity has Manual Boycott input box");
        java.nio.file.Path svcPath = java.nio.file.Paths.get("app/src/main/java/com/vrksignatures/sudhaautobot/SudhaAccessibilityService.java");
        if (!java.nio.file.Files.exists(svcPath)) svcPath = java.nio.file.Paths.get("../../app/src/main/java/com/vrksignatures/sudhaautobot/SudhaAccessibilityService.java");
        String svcSrc = new String(java.nio.file.Files.readAllBytes(svcPath));
        check(svcSrc.contains("parseAllCustomerBoxes"), "Service uses universal parseAllCustomerBoxes");
        check(svcSrc.contains("manualBoycottIds"), "Service filters ONLY via manualBoycottIds");

        
        // 12. Bare digits "2157" typed in Last Done box matches "SMR2157" on screen -> opens "20173" immediately!
        check(RetailerPolicy.sameCustomerId("2157", "SMR2157"), "bare '2157' matches 'SMR2157'");
        check(RetailerPolicy.sameCustomerId("20173", "20173"), "bare '20173' matches '20173'");
        check(!RetailerPolicy.sameCustomerId("2157", "20173"), "'2157' does NOT match '20173'");
        RetailerSequence bareSeq = new RetailerSequence();
        RetailerSequence.Decision dBare = bareSeq.decideAnyId(cap2Ids, "2157", id -> false);
        check(dBare.action == RetailerSequence.Action.OPEN && "20173".equals(dBare.id),
                "Typing bare '2157' immediately opens '20173' (never scrolls past!)");

        System.out.println("CHECKS " + checks + " passed");
    }
}
