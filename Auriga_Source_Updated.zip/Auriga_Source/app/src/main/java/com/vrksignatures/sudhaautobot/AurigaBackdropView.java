package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/**
 * 60fps Layered Silk-Wave Canvas on warm cream-ivory (#FDF6EB) matching the reference UI:
 * Wide, luminous translucent violet & pink overlapping silk sheets + fine highlight threads
 * flowing smoothly across the screen so every transparent frosted-glass card refracts them live.
 */
final class AurigaBackdropView extends View {

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint orbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillSilk = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lineSilk = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path wave = new Path();
    private int cachedW = -1, cachedH = -1;

    AurigaBackdropView(Context context) {
        super(context);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        fillSilk.setStyle(Paint.Style.FILL);
        lineSilk.setStyle(Paint.Style.STROKE);
        lineSilk.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        if (w != cachedW || h != cachedH) {
            cachedW = w;
            cachedH = h;
            bgPaint.setShader(new LinearGradient(
                    0, 0, w, h,
                    new int[]{0xFFFDF6EC, 0xFFFCF1E6, 0xFFF7ECF8},
                    new float[]{0f, 0.55f, 1f},
                    Shader.TileMode.CLAMP));
        }
        canvas.drawRect(0, 0, w, h, bgPaint);

        float t = SystemClock.uptimeMillis() / 1000f;
        float d = getResources().getDisplayMetrics().density;

        // Ambient violet & rose glows behind the transparent cards
        drawOrb(canvas, w * (0.86f + 0.08f * (float) Math.sin(t * 0.35f)),
                h * (0.24f + 0.04f * (float) Math.cos(t * 0.25f)), w * 0.62f, 0x4D7C3AED);
        drawOrb(canvas, w * (0.12f + 0.09f * (float) Math.cos(t * 0.30f)),
                h * (0.50f + 0.05f * (float) Math.sin(t * 0.28f)), w * 0.58f, 0x45EC4899);
        drawOrb(canvas, w * (0.82f + 0.07f * (float) Math.sin(t * 0.26f + 1.2f)),
                h * (0.64f + 0.04f * (float) Math.cos(t * 0.22f)), w * 0.55f, 0x3D8B5CF6);

        // Layered wide translucent 3D silk ribbons sweeping diagonally (clearly visible through cards!)
        drawSilkSheet(canvas, w, h, t, d, 0.42f, 0.28f, d * 95f, 0x667C3AED, 0x55EC4899);
        drawSilkSheet(canvas, w, h, t + 1.6f, d, 0.49f, 0.22f, d * 78f, 0x52EC4899, 0x456D28D9);
        drawSilkSheet(canvas, w, h, t + 3.1f, d, 0.56f, 0.32f, d * 56f, 0x388B5CF6, 0x3310B981);

        // Crisp silk specular edge threads
        drawSilkThread(canvas, w, h, t, d, 0.42f, 0.28f, 0xAA7C3AED, d * 2.2f);
        drawSilkThread(canvas, w, h, t + 1.6f, d, 0.49f, 0.22f, 0x99EC4899, d * 1.8f);

        if (isShown()) postInvalidateOnAnimation();
    }

    private void drawSilkSheet(Canvas canvas, int w, int h, float t, float d,
                               float yFrac, float speed, float thickness, int cStart, int cEnd) {
        wave.reset();
        float y0 = h * (yFrac + 0.20f);
        float y1 = h * (yFrac - 0.22f);
        float amp = d * 32f;
        int steps = 16;

        wave.moveTo(-d * 40f, y0);
        for (int i = 1; i <= steps; i++) {
            float f = i / (float) steps;
            float x = -d * 40f + (w + d * 80f) * f;
            float y = y0 + (y1 - y0) * f + amp * (float) Math.sin(f * 4.5f + t * speed);
            wave.lineTo(x, y);
        }
        for (int i = steps; i >= 0; i--) {
            float f = i / (float) steps;
            float x = -d * 40f + (w + d * 80f) * f;
            float pinch = 0.55f + 0.45f * (float) Math.sin(f * 3.14f + t * 0.4f);
            float y = y0 + (y1 - y0) * f + amp * (float) Math.sin(f * 4.5f + t * speed + 0.45f) + thickness * pinch;
            wave.lineTo(x, y);
        }
        wave.close();
        fillSilk.setShader(new LinearGradient(0, y0, w, y1, cStart, cEnd, Shader.TileMode.CLAMP));
        canvas.drawPath(wave, fillSilk);
    }

    private void drawSilkThread(Canvas canvas, int w, int h, float t, float d,
                                float yFrac, float speed, int color, float stroke) {
        wave.reset();
        float y0 = h * (yFrac + 0.20f);
        float y1 = h * (yFrac - 0.22f);
        float amp = d * 32f;
        int steps = 16;
        wave.moveTo(-d * 40f, y0);
        for (int i = 1; i <= steps; i++) {
            float f = i / (float) steps;
            float x = -d * 40f + (w + d * 80f) * f;
            float y = y0 + (y1 - y0) * f + amp * (float) Math.sin(f * 4.5f + t * speed);
            wave.lineTo(x, y);
        }
        lineSilk.setColor(color);
        lineSilk.setStrokeWidth(stroke);
        canvas.drawPath(wave, lineSilk);
    }

    private void drawOrb(Canvas canvas, float cx, float cy, float radius, int color) {
        orbPaint.setShader(new RadialGradient(cx, cy, radius,
                new int[]{color, 0x00000000}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, radius, orbPaint);
    }
}
