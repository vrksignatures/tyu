package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

/**
 * Compact 26-line razor-crisp audio spectrum waveform (emerald -> cyan -> violet -> neon pink).
 */
final class WaveBars extends View {
    private static final int BARS = 26;
    private static final int[] SPECTRUM = {
            0xFF10B981, 0xFF10B981, 0xFF34D399, 0xFF5EEAD4, 0xFF2DD4BF,
            0xFF38BDF8, 0xFF60A5FA, 0xFF6366F1, 0xFF7C3AED, 0xFF8B5CF6,
            0xFFA855F7, 0xFFC084FC, 0xFFD946EF, 0xFFEC4899, 0xFFF472B6,
            0xFFFB7185, 0xFFF472B6, 0xFFEC4899, 0xFFD946EF, 0xFFA855F7,
            0xFF8B5CF6, 0xFF6366F1, 0xFF38BDF8, 0xFF5EEAD4, 0xFF34D399, 0xFF10B981
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bar = new RectF();
    private boolean playing;

    WaveBars(Context context) {
        super(context);
        setSoundEffectsEnabled(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    void setPlaying(boolean on) {
        if (playing == on) return;
        playing = on;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float d = getResources().getDisplayMetrics().density;
        float slot = w / BARS;
        float thick = Math.min(d * 2.1f, slot * 0.52f);
        float t = SystemClock.uptimeMillis() / 1000f;
        float mid = (BARS - 1) / 2f;

        for (int i = 0; i < BARS; i++) {
            float normDist = Math.abs(i - mid) / mid;
            float envelope = 0.26f + 0.74f * (float) Math.pow(1f - normDist, 0.85f);
            float h1 = (float) Math.sin(t * 4.2f + i * 0.55f);
            float h2 = (float) Math.sin(t * 2.7f - i * 0.85f);
            float energy = playing ? (0.30f + 0.70f * (0.5f + 0.25f * h1 + 0.25f * h2)) : 0.24f;
            float bh = Math.max(d * 3f, h * envelope * energy);
            float left = i * slot + (slot - thick) / 2f;
            float top = (h - bh) / 2f;
            paint.setColor(playing ? SPECTRUM[i % SPECTRUM.length] : 0x668F84AA);
            bar.set(left, top, left + thick, top + bh);
            canvas.drawRoundRect(bar, thick / 2f, thick / 2f, paint);
        }
        if (playing && isShown()) postInvalidateOnAnimation();
    }
}
