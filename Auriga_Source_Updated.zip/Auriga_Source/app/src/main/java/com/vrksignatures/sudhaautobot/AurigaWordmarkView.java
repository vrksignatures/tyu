package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/**
 * Editorial ligature-serif brand wordmark for "Auriga" inspired by Runiga:
 * High-contrast sculpted serif (EB Garamond) + signature sweeping calligraphic swash arc
 * curving gracefully from the 'i' over 'g' and 'a' into the tail, with indigo->violet->pink gradient & sheen.
 */
final class AurigaWordmarkView extends View {

    private static final String WORD = "Auriga";
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint swashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint terminalPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path wordPath = new Path();
    private final Path swashPath = new Path();
    private final Path terminalPath = new Path();
    private int cachedW = -1;

    AurigaWordmarkView(Context context) {
        super(context);
        float d = context.getResources().getDisplayMetrics().density;
        float textSize = d * 40f;

        textPaint.setTypeface(AurigaFonts.brand(context));
        textPaint.setTextSize(textSize);
        textPaint.setLetterSpacing(-0.01f);

        shadowPaint.setTypeface(AurigaFonts.brand(context));
        shadowPaint.setTextSize(textSize);
        shadowPaint.setLetterSpacing(-0.01f);
        shadowPaint.setColor(0x264C1D95);

        glintPaint.setTypeface(AurigaFonts.brand(context));
        glintPaint.setTextSize(textSize);
        glintPaint.setLetterSpacing(-0.01f);

        textPaint.getTextPath(WORD, 0, WORD.length(), 0f, 0f, wordPath);

        swashPaint.setStyle(Paint.Style.STROKE);
        swashPaint.setStrokeCap(Paint.Cap.ROUND);
        swashPaint.setStrokeWidth(Math.max(1.5f, d * 1.45f));
        terminalPaint.setStyle(Paint.Style.FILL);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        float d = getResources().getDisplayMetrics().density;
        float w = textPaint.measureText(WORD) + d * 26f;
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float h = (fm.descent - fm.ascent) + d * 14f;
        setMeasuredDimension(
                resolveSize((int) Math.ceil(w), widthMeasureSpec),
                resolveSize((int) Math.ceil(h), heightMeasureSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float d = getResources().getDisplayMetrics().density;
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float baseline = (h - fm.ascent - fm.descent) * 0.54f;
        float textW = textPaint.measureText(WORD);

        if (w != cachedW) {
            cachedW = w;
            LinearGradient grad = new LinearGradient(
                    0, 0, w, 0,
                    new int[]{0xFF1A0B4B, 0xFF6D28D9, 0xFFEC4899, 0xFF4C1D95},
                    new float[]{0f, 0.44f, 0.80f, 1f},
                    Shader.TileMode.CLAMP);
            textPaint.setShader(grad);
            swashPaint.setShader(grad);
            terminalPaint.setShader(grad);
        }

        // Subtle sculpted drop shadow + primary editorial serif wordmark
        canvas.save();
        canvas.translate(d * 1.4f, baseline + d * 1.8f);
        canvas.drawPath(wordPath, shadowPaint);
        canvas.restore();

        canvas.save();
        canvas.translate(0f, baseline);
        canvas.drawPath(wordPath, textPaint);
        canvas.restore();

        // Fine calligraphic ligature sweeps from the i above the final letters and around the a.
        float iX = textPaint.measureText("Aur") + d * 3.5f;
        float topY = baseline + fm.ascent * 0.78f;
        float endX = textW + d * 21f;
        float tailY = topY + d * 4f;

        swashPath.reset();
        swashPath.moveTo(iX, topY + d * 2f);
        swashPath.cubicTo(
                iX + d * 20f, topY - d * 12f,
                textW + d * 30f, topY - d * 17f,
                textW + d * 24f, baseline - d * 8f);
        swashPath.cubicTo(
                textW + d * 22f, baseline + d * 3f,
                textW + d * 8f, baseline + d * 5f,
                textW + d * 1f, baseline - d * 3f);
        swashPath.cubicTo(
                textW + d * 11f, baseline - d * 19f,
                textW + d * 27f, baseline - d * 24f,
                endX, tailY);
        canvas.drawPath(swashPath, swashPaint);

        // The outer swash finishes in a small filled teardrop terminal.
        terminalPath.reset();
        terminalPath.moveTo(endX, tailY);
        terminalPath.cubicTo(
                endX - d * 1f, tailY + d * 2f,
                endX - d * 6f, tailY + d * 3f,
                endX - d * 5f, tailY + d * 6f);
        terminalPath.cubicTo(
                endX - d * 2f, tailY + d * 6f,
                endX + d * 1.5f, tailY + d * 3f,
                endX, tailY);
        terminalPath.close();
        canvas.drawPath(terminalPath, terminalPaint);

        // Smooth glossy specular glint sweeping across the letters every 4.2s
        float cycle = (SystemClock.uptimeMillis() % 4200L) / 4200f;
        if (cycle < 0.32f) {
            float p = cycle / 0.32f;
            float gx = -w * 0.25f + (w * 1.5f) * p;
            float band = w * 0.22f;
            glintPaint.setShader(new LinearGradient(
                    gx - band, 0, gx + band, 0,
                    new int[]{0x00FFFFFF, 0xBBFFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f},
                    Shader.TileMode.CLAMP));
            canvas.save();
            canvas.translate(0f, baseline);
            canvas.drawPath(wordPath, glintPaint);
            canvas.restore();
        }

        if (isShown()) postInvalidateOnAnimation();
    }
}
