package com.vrksignatures.sudhaautobot;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The look of the app in one place: paper, ink, one brand colour and three signals; two
 * weights of one typeface; and the few shapes everything is built from (a card, three kinds
 * of button). The same colours are in {@code res/values/colors.xml} for the layouts.
 *
 * <p>Framework widgets only - no AndroidX, no Material library - so the APK stays small and
 * there is nothing to keep in step with a design system.</p>
 */
final class MagicUi {

    // Paper.
    static final int BG = 0xFFFDF7EE;
    static final int SURFACE = 0xD9FFFFFF;
    static final int LINE = 0xCCFFFFFF;
    // Ink.
    static final int TEXT = 0xFF1A0B4B;
    static final int MUTED = 0xFF5D517A;
    static final int FAINT = 0xFF8F84AA;
    // The navy of Aakriti's avatar, and a tint of it.
    static final int BRAND = 0xFF6D28D9;
    static final int BRAND_SOFT = 0x1F6D28D9;
    // Signals.
    static final int GOOD = 0xFF10B981;
    static final int WARN = 0xFFF59E0B;
    static final int BAD = 0xFFEF4444;
    static final int GOOD_SOFT = 0x2210B981;
    static final int WARN_SOFT = 0x22F59E0B;
    static final int BAD_SOFT = 0x22EF4444;

    static final Typeface REGULAR = Typeface.create("sans-serif", Typeface.NORMAL);
    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);


    /** Corner radius of a card, in dp. Buttons and fields use {@link #RADIUS_CONTROL}. */
    static final float RADIUS_CARD = 24;
    static final float RADIUS_CONTROL = 14;

    private MagicUi() {
    }

    static int dp(Context context, float value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (alpha << 24);
    }

    // ------------------------------------------------------------------ shapes

    static GradientDrawable rounded(Context context, int fill, int stroke, float radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(context, radiusDp));
        if (stroke != 0) shape.setStroke(Math.max(1, dp(context, 1)), stroke);
        return shape;
    }

    private static Drawable pressable(Context context, int fill, int stroke, float radiusDp, int ripple) {
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(context, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(ripple),
                rounded(context, fill, stroke, radiusDp), mask);
    }

    // ------------------------------------------------------------------- views

    static TextView text(Context context, CharSequence words, float sp, int color) {
        TextView view = new TextView(context);
        view.setText(words);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setTypeface(AurigaFonts.regular(context));
        return view;
    }

    private static TextView button(Context context, CharSequence words, float sp, int textColor,
                                   Drawable background, int minHeightDp, View.OnClickListener action) {
        TextView view = text(context, words, sp, textColor);
        view.setTypeface(AurigaFonts.heading(context));
        view.setGravity(Gravity.CENTER);
        view.setBackground(background);
        view.setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8));
        view.setMinHeight(dp(context, minHeightDp));
        view.setMaxLines(2);
        view.setClickable(true);
        view.setFocusable(true);
        view.setOnClickListener(action);
        springy(view);
        return view;
    }

    static Drawable raised3dPill(Context context, int topStart, int topEnd, int lipColor, int rimColor, float radiusDp) {
        int lift = dp(context, 4);
        GradientDrawable lip = new GradientDrawable();
        lip.setColor(lipColor);
        lip.setCornerRadius(dp(context, radiusDp));

        GradientDrawable face = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{topStart, topEnd});
        face.setCornerRadius(dp(context, radiusDp));
        face.setStroke(Math.max(1, dp(context, 1)), rimColor);

        android.graphics.drawable.LayerDrawable stack =
                new android.graphics.drawable.LayerDrawable(new Drawable[]{lip, face});
        stack.setLayerInset(0, 0, lift, 0, 0);
        stack.setLayerInset(1, 0, 0, 0, lift);

        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(context, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), stack, mask);
    }

    static GradientDrawable glassCardBg(Context context) {
        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0x9EFFFFFF, 0x7CFDF8F2, 0x8CF8F0FA});
        shape.setCornerRadius(dp(context, RADIUS_CARD));
        shape.setStroke(Math.max(1, dp(context, 1.3f)), 0xE6FFFFFF);
        return shape;
    }

    static void attach3dPress(View view) {
        final float pressY = dp(view.getContext(), 3);
        view.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.95f).scaleY(0.95f).translationY(pressY)
                        .setDuration(80).start();
            } else if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).translationY(0f)
                        .setInterpolator(new android.view.animation.OvershootInterpolator(2.2f))
                        .setDuration(220).start();
            }
            return false;
        });
    }

    static Drawable liquidGlassPill(Context context, int start, int end, int rim, float radiusDp) {
        GradientDrawable face = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, end});
        face.setCornerRadius(dp(context, radiusDp));
        face.setStroke(Math.max(1, dp(context, 1)), rim);
        GradientDrawable mask = new GradientDrawable();
        mask.setColor(0xFFFFFFFF);
        mask.setCornerRadius(dp(context, radiusDp));
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), face, mask);
    }

    /** Vibrant Electric Violet pill matching the reference Start CTA. */
    static TextView primaryButton(Context context, CharSequence words, View.OnClickListener action) {
        Drawable bg = liquidGlassPill(context, 0xFF7C3AED, 0xFF5B21B6, 0x88FFFFFF, 22);
        TextView btn = button(context, words, 16, 0xFFFFFFFF, bg, 56, action);
        btn.setElevation(dp(context, 10));
        attach3dPress(btn);
        return btn;
    }

    /** Frosted white glass pill with soft pink rim matching the reference Pause CTA. */
    static TextView tonalButton(Context context, CharSequence words, View.OnClickListener action) {
        Drawable bg = liquidGlassPill(context, 0x8CFFFFFF, 0x6BFDF2F8, 0xE6F472B6, 22);
        TextView btn = button(context, words, 15, 0xFFEC4899, bg, 56, action);
        btn.setElevation(dp(context, 6));
        attach3dPress(btn);
        return btn;
    }

    /** Clean frosted glass action button. */
    static TextView quietButton(Context context, CharSequence words, int color,
                                View.OnClickListener action) {
        Drawable bg = liquidGlassPill(context, 0x8CFFFFFF, 0x70F5F0FA, 0x667C3AED, 18);
        TextView btn = button(context, words, 13, color, bg, 44, action);
        btn.setElevation(dp(context, 3));
        attach3dPress(btn);
        return btn;
    }

    /** Frosted glass chip. */
    static TextView chip(Context context, CharSequence words, View.OnClickListener action) {
        Drawable bg = liquidGlassPill(context, 0xE6FFFFFF, 0xCCF3E8FF, 0x557C3AED, 20);
        TextView view = button(context, words, 12, 0xFF6D28D9, bg, 36, action);
        view.setPadding(dp(context, 14), dp(context, 6), dp(context, 14), dp(context, 6));
        view.setMaxLines(1);
        attach3dPress(view);
        return view;
    }

    static LinearLayout card(Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(glassCardBg(context));
        card.setElevation(dp(context, 14));
        int pad = dp(context, 18);
        card.setPadding(pad, pad, pad, pad);
        return card;
    }

    /** A vector icon in one colour. */
    static ImageView icon(Context context, int drawable, int color) {
        ImageView view = new ImageView(context);
        view.setImageResource(drawable);
        view.setColorFilter(color);
        view.setScaleType(ImageView.ScaleType.FIT_CENTER);
        return view;
    }

    /** A hairline between rows. */
    static View divider(Context context) {
        View line = new View(context);
        line.setBackgroundColor(LINE);
        return line;
    }

    /**
     * Silent UI: switches off the "click" the phone plays when something is tapped, for a
     * view and everything inside it. (The phone only plays it when "touch sounds" is on in
     * its settings, but this app does not add to it either way.) Call again after adding views.
     */
    static void silence(View view) {
        if (view == null) return;
        view.setSoundEffectsEnabled(false);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) silence(group.getChildAt(i));
        }
    }

    static LinearLayout.LayoutParams fill() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    static LinearLayout.LayoutParams fill(Context context, float topDp) {
        LinearLayout.LayoutParams params = fill();
        params.topMargin = dp(context, topDp);
        return params;
    }

    static LinearLayout.LayoutParams wrap(Context context, float topDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(context, topDp);
        return params;
    }

    static LinearLayout.LayoutParams share(Context context, float weight, float startDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        params.setMarginStart(dp(context, startDp));
        return params;
    }

    // ------------------------------------------------------------------ motion

    /** The view gives very slightly when pressed. Clicks still arrive. */
    @SuppressLint("ClickableViewAccessibility")
    static void springy(View view) {
        view.setOnTouchListener((pressed, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pressed.animate().scaleX(0.98f).scaleY(0.98f).setDuration(80).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pressed.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }
}
