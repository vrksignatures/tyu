package com.vrksignatures.sudhaautobot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Pure-Java (zero Android SDK dependency) core rules for:
 * 1. Section 5 Zero-Hardcoding Distributor vs Retailer bidirectional + cross-page adjacency classification.
 * 2. Arbitrary exact Customer ID acceptance (SMR*, numeric, alpha, alphanumeric, hyphenated, spaced).
 * 3. Section 10 Customer Demand smart pack math & Employee's Chance anti-bot scatter.
 */
public final class UpgradeRules {

    private UpgradeRules() {
    }

    public static final class Card {
        public final String customerId;
        public final String boldOrangeName;
        public final boolean isDistributor;
        public final boolean isRetailer;

        public Card(String customerId, String boldOrangeName, boolean isDistributor, boolean isRetailer) {
            this.customerId = customerId == null ? "" : customerId.trim().toUpperCase(Locale.ROOT);
            this.boldOrangeName = boldOrangeName == null ? "" : boldOrangeName.trim();
            this.isDistributor = isDistributor;
            this.isRetailer = isRetailer;
        }

        public String normalizedName() {
            return boldOrangeName.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
    }

    public static final class Classification {
        public final Set<String> distributorIds;
        public final Set<String> distributorOwnedRetailerIds;
        public final Set<String> allBlacklistedIds;
        public final List<Card> genuineRetailers;
        /** Non-null ONLY when the bottom-most card on this page is a (Dist) card. */
        public final String trailingDistributorName;

        public Classification(Set<String> distributorIds, Set<String> distributorOwnedRetailerIds,
                              Set<String> allBlacklistedIds, List<Card> genuineRetailers,
                              String trailingDistributorName) {
            this.distributorIds = distributorIds;
            this.distributorOwnedRetailerIds = distributorOwnedRetailerIds;
            this.allBlacklistedIds = allBlacklistedIds;
            this.genuineRetailers = genuineRetailers;
            this.trailingDistributorName = trailingDistributorName;
        }
    }

    public static Classification classifyCards(List<Card> cards) {
        return classifyCardsWithCarryOver(cards, null);
    }

    /**
     * Classifies visible cards with cross-page boundary carry-over:
     * - If the previous page ended with a (Dist) card (`prevPageTrailingDistName != null`)
     *   AND the first card on this new page is a (Retailer) with the exact same normalized name,
     *   it is classified as that distributor's immediate shadow and boycotted!
     * - If the first card on this new page has a DIFFERENT name, it is a genuine retailer.
     * - If the last card on THIS page is a (Dist) card, `trailingDistributorName` is returned
     *   so the caller slows down the next scroll and checks the very next card carefully.
     */
    public static Classification classifyCardsWithCarryOver(List<Card> cards,
                                                            String prevPageTrailingDistName) {
        Set<String> distIds = new LinkedHashSet<>();
        Set<String> distOwned = new LinkedHashSet<>();
        Set<String> allBlacklist = new LinkedHashSet<>();
        Set<Integer> excluded = new LinkedHashSet<>();

        if (cards == null || cards.isEmpty()) {
            return new Classification(distIds, distOwned, allBlacklist, Collections.emptyList(), null);
        }

        // Cross-page boundary check: top card of new page immediately below previous page's bottom (Dist)
        if (prevPageTrailingDistName != null && !prevPageTrailingDistName.trim().isEmpty()) {
            String carry = prevPageTrailingDistName.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
            Card first = cards.get(0);
            if (first.isRetailer && carry.equals(first.normalizedName())) {
                excluded.add(0);
                if (!first.customerId.isEmpty()) {
                    distOwned.add(first.customerId);
                    allBlacklist.add(first.customerId);
                }
            }
        }

        // Same-page bidirectional adjacency check (i - 1 and i + 1)
        for (int i = 0; i < cards.size(); i++) {
            Card c = cards.get(i);
            if (!c.isDistributor) continue;
            excluded.add(i);
            if (!c.customerId.isEmpty()) {
                distIds.add(c.customerId);
                allBlacklist.add(c.customerId);
            }
            String dName = c.normalizedName();
            if (dName.isEmpty()) continue;

            for (int adjIdx : new int[]{i - 1, i + 1}) {
                if (adjIdx < 0 || adjIdx >= cards.size()) continue;
                Card adj = cards.get(adjIdx);
                if (adj.isRetailer && dName.equals(adj.normalizedName())) {
                    excluded.add(adjIdx);
                    if (!adj.customerId.isEmpty()) {
                        distOwned.add(adj.customerId);
                        allBlacklist.add(adj.customerId);
                    }
                }
            }
        }

        List<Card> genuine = new ArrayList<>();
        for (int i = 0; i < cards.size(); i++) {
            if (!excluded.contains(i) && cards.get(i).isRetailer) {
                genuine.add(cards.get(i));
            }
        }

        Card last = cards.get(cards.size() - 1);
        String trailingDist = last.isDistributor && !last.normalizedName().isEmpty()
                ? last.normalizedName() : null;

        return new Classification(distIds, distOwned, allBlacklist, genuine, trailingDist);
    }

    public static Map<Integer, Integer> generateScatteredPlan(String dateStr, int totalExtraMl,
                                                              int targetRetailers, int expectedRetailers) {
        Map<Integer, Integer> result = new LinkedHashMap<>();
        int totalHalfLiters = totalExtraMl / 500;
        if (totalHalfLiters <= 0 || targetRetailers <= 0 || expectedRetailers <= 0) return result;

        int chosenCount = Math.max(1, Math.min(targetRetailers, Math.min(expectedRetailers, totalHalfLiters)));
        long seed = (dateStr + "|" + totalExtraMl + "|" + chosenCount + "|" + expectedRetailers).hashCode();
        Random rng = new Random(seed);

        List<Integer> pool = new ArrayList<>(expectedRetailers);
        for (int i = 1; i <= expectedRetailers; i++) pool.add(i);
        Collections.shuffle(pool, rng);

        List<Integer> chosen = new ArrayList<>(pool.subList(0, chosenCount));
        Collections.sort(chosen);

        Map<Integer, Integer> units = new LinkedHashMap<>();
        for (int idx : chosen) units.put(idx, 1);
        int remaining = totalHalfLiters - chosenCount;

        List<Integer> round = new ArrayList<>(chosen);
        while (remaining > 0) {
            Collections.shuffle(round, rng);
            for (int idx : round) {
                if (remaining <= 0) break;
                int add = (remaining >= 2 && rng.nextBoolean()) ? 2 : 1;
                units.put(idx, units.get(idx) + add);
                remaining -= add;
            }
        }
        for (Map.Entry<Integer, Integer> e : units.entrySet()) {
            result.put(e.getKey(), e.getValue() * 500);
        }
        return result;
    }

    /** Returns [packSizeMl (1000 or 500), newQty] or null if invalid. */
    public static int[] resolvePackDelta(int deltaMl, int qty1000, int qty500) {
        if (deltaMl == 0) return null;
        if (deltaMl % 1000 == 0 && qty1000 > 0 && (qty1000 + deltaMl / 1000) >= 0) {
            return new int[]{1000, qty1000 + deltaMl / 1000};
        }
        if (deltaMl % 500 == 0 && qty500 > 0 && (qty500 + deltaMl / 500) >= 0) {
            return new int[]{500, qty500 + deltaMl / 500};
        }
        if (deltaMl % 1000 == 0 && deltaMl > 0) {
            return new int[]{1000, qty1000 + deltaMl / 1000};
        }
        if (deltaMl % 500 == 0) {
            return new int[]{500, Math.max(0, qty500 + deltaMl / 500)};
        }
        return null;
    }

    private static final java.util.regex.Pattern CUSTOMER_ID_INLINE =
            java.util.regex.Pattern.compile("(?i)customer\\s*id\\s*:?\\s*([A-Za-z0-9][A-Za-z0-9_\\- ]{0,23})");
    private static final java.util.regex.Pattern PHONE_LIKE =
            java.util.regex.Pattern.compile("^\\+?\\d{10,13}$");

    /**
     * Parses a single customer card from its ordered child text labels.
     * Supports BOTH:
     * - Real Sudha app split TextViews: ["Delivery Point", "(Dist)"/"(Retailer)", "Customer Id:", "<ID>", "<Shop Name>", ...]
     * - Legacy combined TextViews: ["Delivery Point (Retailer)", "Customer Id: 20173", "Abhishek Enterprises", ...]
     */
    public static Card extractCardFromTexts(List<String> texts) {
        if (texts == null || texts.isEmpty()) return null;
        boolean isDist = false;
        boolean isRet = false;
        String customerId = "";
        int idValueIndex = -1;
        int roleIndex = -1;

        for (int i = 0; i < texts.size(); i++) {
            String raw = texts.get(i);
            if (raw == null) continue;
            String t = raw.trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);

            if (low.equals("(dist)") || low.contains("delivery point (dist)") || low.equals("dist")) {
                isDist = true;
                if (roleIndex < 0) roleIndex = i;
            } else if (low.equals("(retailer)") || low.contains("delivery point (retailer)") || low.equals("retailer")) {
                isRet = true;
                if (roleIndex < 0) roleIndex = i;
            }

            if (customerId.isEmpty()) {
                java.util.regex.Matcher m = CUSTOMER_ID_INLINE.matcher(t);
                if (m.find() && m.group(1) != null && !m.group(1).trim().isEmpty()) {
                    customerId = m.group(1).trim().toUpperCase(Locale.ROOT);
                    idValueIndex = i;
                } else if (low.equals("customer id:") || low.equals("customer id")) {
                    for (int j = i + 1; j < Math.min(texts.size(), i + 3); j++) {
                        String next = texts.get(j) == null ? "" : texts.get(j).trim();
                        if (!next.isEmpty() && !isMetadataLabel(next)) {
                            customerId = next.toUpperCase(Locale.ROOT);
                            idValueIndex = j;
                            break;
                        }
                    }
                }
            }
        }

        if (!isDist && !isRet) return null;
        if (isDist) isRet = false;

        // Extract Shop Name positionally: immediately after Customer ID (or role), BEFORE S.O(s) / P.R (Id) / Route / Phone.
        String shopName = "";
        int startIdx = idValueIndex >= 0 ? idValueIndex + 1 : (roleIndex >= 0 ? roleIndex + 1 : 0);
        for (int i = startIdx; i < texts.size(); i++) {
            String t = texts.get(i) == null ? "" : texts.get(i).trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.startsWith("s.o(") || low.startsWith("p.r") || low.startsWith("p.r.")) break;
            if (isNonShopField(t, customerId)) continue;
            shopName = t;
            break;
        }
        // Fallback scan from top if shop name appeared before Customer Id in an alternate layout
        if (shopName.isEmpty()) {
            for (int i = 0; i < texts.size(); i++) {
                String t = texts.get(i) == null ? "" : texts.get(i).trim();
                if (t.isEmpty()) continue;
                String low = t.toLowerCase(Locale.ROOT);
                if (low.startsWith("s.o(") || low.startsWith("p.r") || low.startsWith("p.r.")) break;
                if (isNonShopField(t, customerId)) continue;
                shopName = t;
                break;
            }
        }

        // Never drop a genuine card just because Customer ID is missing: fall back to normalized name key.
        if (customerId.isEmpty() && !shopName.isEmpty()) {
            customerId = "NAME:" + shopName.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
        if (customerId.isEmpty()) return null;

        return new Card(customerId, shopName, isDist, isRet);
    }

    /** Chunks a flat screen label stream into individual Card records (used as fallback & for capture self-tests). */
    public static List<Card> extractCardsFromFlatLabels(List<String> allLabels) {
        List<Card> out = new ArrayList<>();
        if (allLabels == null || allLabels.isEmpty()) return out;
        List<String> current = null;
        for (String raw : allLabels) {
            if (raw == null) continue;
            String t = raw.trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.equals("delivery point") || low.contains("delivery point (dist)") || low.contains("delivery point (retailer)")) {
                if (current != null && !current.isEmpty()) {
                    Card c = extractCardFromTexts(current);
                    if (c != null) out.add(c);
                }
                current = new ArrayList<>();
            }
            if (current != null) current.add(t);
        }
        if (current != null && !current.isEmpty()) {
            Card c = extractCardFromTexts(current);
            if (c != null) out.add(c);
        }
        return out;
    }

    private static boolean isMetadataLabel(String t) {
        String low = t.toLowerCase(Locale.ROOT);
        return low.equals("delivery point") || low.equals("(dist)") || low.equals("(retailer)")
                || low.contains("delivery point (") || low.startsWith("customer id");
    }

    private static boolean isNonShopField(String t, String customerId) {
        String low = t.toLowerCase(Locale.ROOT);
        if (isMetadataLabel(t)) return true;
        if (!customerId.isEmpty() && t.equalsIgnoreCase(customerId)) return true;
        if (low.startsWith("rtr_") || low.startsWith("route ") || low.startsWith("s.o(")
                || low.startsWith("p.r") || low.startsWith("total customers")
                || low.endsWith("[so]") || low.endsWith("[sd]")
                || low.equals("ara_plant") || PHONE_LIKE.matcher(t).matches()) {
            return true;
        }
        return false;
    }


    /**
     * Parses the user's Manual Boycott / Reject Customer IDs text (comma, newline, or semicolon separated).
     * Example: "SM65, 65, SM41" -> {"SM65", "65", "SM41"}. Zero SMR assumptions.
     */
    public static Set<String> parseManualBoycottText(String raw) {
        Set<String> out = new LinkedHashSet<>();
        if (raw == null || raw.trim().isEmpty()) return out;
        String[] parts = raw.split("[,;\\r\\n]+");
        for (String p : parts) {
            String norm = normalizeBoycottToken(p);
            if (!norm.isEmpty()) out.add(norm);
        }
        return out;
    }

    public static String normalizeBoycottToken(String raw) {
        if (raw == null) return "";
        String t = raw.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
        if (t.matches("SMR\\s+[0-9]{1,6}") || t.matches("SM\\s+[0-9]{1,6}")) {
            t = t.replaceAll("\\s+", "");
        }
        return t;
    }

    /** True when customerId matches any entry in the user's Manual Boycott list (case/space tolerant). */
    public static boolean isBoycotted(String customerId, Set<String> boycottSet) {
        if (boycottSet == null || boycottSet.isEmpty() || customerId == null) return false;
        String norm = normalizeBoycottToken(customerId);
        if (norm.isEmpty()) return false;
        if (boycottSet.contains(norm)) return true;
        String compact = norm.replaceAll("\\s+", "");
        for (String b : boycottSet) {
            String nb = normalizeBoycottToken(b);
            if (nb.equals(norm) || nb.replaceAll("\\s+", "").equals(compact)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Universal Customer Box parser: parses ANY customer card box regardless of ID format (SMR*, numeric, alpha)
     * and regardless of whether "(Dist)" or "(Retailer)" label is present or scrolled off.
     */
    public static Card extractAnyCustomerBox(List<String> texts) {
        if (texts == null || texts.isEmpty()) return null;
        Card strict = extractCardFromTexts(texts);
        if (strict != null) return strict;

        String customerId = "";
        int idValueIndex = -1;
        for (int i = 0; i < texts.size(); i++) {
            String raw = texts.get(i);
            if (raw == null) continue;
            String t = raw.trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            java.util.regex.Matcher m = CUSTOMER_ID_INLINE.matcher(t);
            if (m.find() && m.group(1) != null && !m.group(1).trim().isEmpty()) {
                customerId = m.group(1).trim().toUpperCase(Locale.ROOT);
                idValueIndex = i;
                break;
            } else if (low.equals("customer id:") || low.equals("customer id")) {
                for (int j = i + 1; j < Math.min(texts.size(), i + 3); j++) {
                    String next = texts.get(j) == null ? "" : texts.get(j).trim();
                    if (!next.isEmpty() && !isMetadataLabel(next)) {
                        customerId = next.toUpperCase(Locale.ROOT);
                        idValueIndex = j;
                        break;
                    }
                }
                if (!customerId.isEmpty()) break;
            }
        }

        String shopName = "";
        int startIdx = idValueIndex >= 0 ? idValueIndex + 1 : 0;
        for (int i = startIdx; i < texts.size(); i++) {
            String t = texts.get(i) == null ? "" : texts.get(i).trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.startsWith("s.o(") || low.startsWith("p.r") || low.startsWith("p.r.")) break;
            if (isNonShopField(t, customerId)) continue;
            shopName = t;
            break;
        }
        if (customerId.isEmpty() && !shopName.isEmpty()) {
            customerId = "NAME:" + shopName.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
        if (customerId.isEmpty()) return null;
        return new Card(customerId, shopName, false, true);
    }

    /**
     * All-Boxes + Manual Boycott filter: keeps EVERY customer box in exact top-to-bottom order
     * EXCEPT those whose Customer ID is in the user's Manual Boycott list. Zero SMR checks!
     */
    public static List<Card> filterOutBoycotted(List<Card> boxes, Set<String> boycottSet) {
        List<Card> eligible = new ArrayList<>();
        if (boxes == null || boxes.isEmpty()) return eligible;
        for (Card c : boxes) {
            if (c == null || c.customerId.isEmpty()) continue;
            if (isBoycotted(c.customerId, boycottSet)) continue;
            eligible.add(c);
        }
        return eligible;
    }

}
