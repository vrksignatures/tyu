package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Flat, playful celestial horse-and-wheel mark for Auriga. */
final class AurigaEmblemView extends View {

    private final Drawable emblem;

    AurigaEmblemView(Context context) {
        super(context);
        emblem = context.getDrawable(R.drawable.ic_auriga_emblem);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        if (emblem != null) {
            emblem.setBounds(0, 0, w, h);
            emblem.draw(canvas);
        }
    }
}
