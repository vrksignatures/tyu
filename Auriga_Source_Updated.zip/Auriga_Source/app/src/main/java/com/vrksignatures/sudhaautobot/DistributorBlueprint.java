package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * TIER 1 PERMANENT MEMORY ("Distributor Blueprint") + Card-Block & Name-First Entity Engine.
 *
 * <p>Grounded in live Accessibility captures of {@code in.vasista.suprabhat}:
 * <ul>
 *   <li>Every customer card inside {@code in.vasista.suprabhat:id/customer_list} is a clickable
 *       {@code FrameLayout} with resource ID {@code in.vasista.suprabhat:id/cv_parent_view}.</li>
 *   <li>Inside each card, {@code "Delivery Point"} and {@code "(Dist)"} / {@code "(Retailer)"}
 *       are SEPARATE sibling TextViews, followed by {@code "Customer Id:"}, {@code <ID>}, and
 *       {@code <Shop Name>}.</li>
 * </ul></p>
 */
public final class DistributorBlueprint {

    public static final String PREFS_NAME = "sudha_tier1_permanent_blueprint";
    private static final String KEY_LEARNED = "blueprint_learned";
    private static final String KEY_BLACKLIST_IDS = "permanent_blacklist_ids";
    private static final String KEY_DIST_COUNT = "distributor_count";
    private static final String KEY_PERM_SCROLLS = "perm_distributor_scrolls";
    private static final String KEY_MANUAL_BOYCOTT_RAW = "manual_boycott_raw";

    public static final String VIEW_ID_CARD = "cv_parent_view";
    public static final String VIEW_ID_LIST = "customer_list";
    public static final String VIEW_ID_FILTER_SPINNER = "primSecLevelsSpinner";
    public static final String VIEW_ID_SHOW_RETAILERS = "ll_show_retailers";

    private static final Pattern CUSTOMER_ID_INLINE =
            Pattern.compile("(?i)customer\\s*id\\s*:?\\s*([A-Za-z0-9][A-Za-z0-9_\\- ]{0,23})");
    private static final Pattern PHONE_LIKE = Pattern.compile("^\\+?\\d{10,13}$");

    private DistributorBlueprint() {
    }

    public static final class CardInfo {
        public final String customerId;
        public final String boldOrangeName;
        public final boolean isDistributor;
        public final boolean isRetailer;
        public final Rect bounds;
        public final AccessibilityNodeInfo containerNode;

        public CardInfo(String customerId, String boldOrangeName, boolean isDistributor,
                        boolean isRetailer, Rect bounds, AccessibilityNodeInfo containerNode) {
            this.customerId = customerId == null ? "" : customerId.trim().toUpperCase(Locale.ROOT);
            this.boldOrangeName = boldOrangeName == null ? "" : boldOrangeName.trim();
            this.isDistributor = isDistributor;
            this.isRetailer = isRetailer;
            this.bounds = bounds == null ? new Rect() : bounds;
            this.containerNode = containerNode;
        }

        public String normalizedName() {
            return boldOrangeName.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
    }

    public static final class Classification {
        public final Set<String> distributorIds;
        public final Set<String> distributorOwnedRetailerIds;
        public final Set<String> allBlacklistedIds;
        public final List<CardInfo> genuineRetailers;
        /** Non-null when the bottom-most visible card is a (Dist) card (triggers slow boundary scroll). */
        public final String trailingDistributorName;

        public Classification(Set<String> distributorIds, Set<String> distributorOwnedRetailerIds,
                              Set<String> allBlacklistedIds, List<CardInfo> genuineRetailers,
                              String trailingDistributorName) {
            this.distributorIds = distributorIds;
            this.distributorOwnedRetailerIds = distributorOwnedRetailerIds;
            this.allBlacklistedIds = allBlacklistedIds;
            this.genuineRetailers = genuineRetailers;
            this.trailingDistributorName = trailingDistributorName;
        }
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards) {
        return classifyOrderedCards(cards, null);
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards,
                                                      String prevPageTrailingDistName) {
        if (cards == null || cards.isEmpty()) {
            return new Classification(new LinkedHashSet<>(), new LinkedHashSet<>(),
                    new LinkedHashSet<>(), Collections.emptyList(), null);
        }
        List<UpgradeRules.Card> pure = new ArrayList<>(cards.size());
        for (CardInfo c : cards) {
            pure.add(new UpgradeRules.Card(c.customerId, c.boldOrangeName, c.isDistributor, c.isRetailer));
        }
        UpgradeRules.Classification res = UpgradeRules.classifyCardsWithCarryOver(pure, prevPageTrailingDistName);
        List<CardInfo> genuine = new ArrayList<>();
        for (CardInfo c : cards) {
            if (c.isRetailer && !res.allBlacklistedIds.contains(c.customerId)) {
                genuine.add(c);
            }
        }
        return new Classification(
                res.distributorIds,
                res.distributorOwnedRetailerIds,
                res.allBlacklistedIds,
                genuine,
                res.trailingDistributorName
        );
    }

    /**
     * Parses ALL visible Customer cards in top-to-bottom order for ANY Customer ID format
     * (SM65, 65, SMR2255, SMR2157, 20173, 19863, ABCD, ABC-17, or even missing ID via Shop Name).
     *
     * <p>Strategy 0: Direct {@code in.vasista.suprabhat:id/cv_parent_view} card-block parsing.<br>
     * Strategy 1: Split ({@code "(Dist)"} / {@code "(Retailer)"}) + combined anchor traversal.<br>
     * Strategy 2: Geometric same-row pairing fallback.</p>
     */
    public static List<CardInfo> parseVisibleCards(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        List<AccessibilityNodeInfo> allNodes = new ArrayList<>();
        collectNodes(root, allNodes, 0);

        List<CardInfo> cards = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();

        // Strategy 0: Exact live Sudha card blocks (in.vasista.suprabhat:id/cv_parent_view)
        for (AccessibilityNodeInfo n : allNodes) {
            String viewId = n.getViewIdResourceName();
            if (viewId == null || !viewId.endsWith(VIEW_ID_CARD)) continue;
            List<String> texts = new ArrayList<>();
            collectTexts(n, texts, 0);
            UpgradeRules.Card parsed = UpgradeRules.extractCardFromTexts(texts);
            if (parsed == null) continue;
            Rect cardRect = new Rect();
            n.getBoundsInScreen(cardRect);
            String key = parsed.customerId + "|" + (parsed.isDistributor ? "D" : "R");
            if (!seen.add(key)) continue;
            cards.add(new CardInfo(parsed.customerId, parsed.boldOrangeName,
                    parsed.isDistributor, parsed.isRetailer, cardRect, n));
        }

        if (!cards.isEmpty()) {
            Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
            return cards;
        }

        // Strategy 1 & 2: Anchor on BOTH split ("(Dist)" / "(Retailer)") AND combined ("Delivery Point (...)") nodes
        List<AccessibilityNodeInfo> anchors = new ArrayList<>();
        for (AccessibilityNodeInfo n : allNodes) {
            String t = AccessibilityTree.textOf(n).trim().toLowerCase(Locale.ROOT);
            if (t.equals("(dist)") || t.equals("(retailer)")
                    || t.contains("delivery point (dist)") || t.contains("delivery point (retailer)")) {
                anchors.add(n);
            }
        }

        for (AccessibilityNodeInfo anchor : anchors) {
            String anchorLower = AccessibilityTree.textOf(anchor).trim().toLowerCase(Locale.ROOT);
            boolean isDist = anchorLower.contains("(dist)");
            boolean isRet = !isDist && anchorLower.contains("(retailer)");

            Rect anchorRect = new Rect();
            anchor.getBoundsInScreen(anchorRect);

            AccessibilityNodeInfo container = findCardContainer(anchor);
            String id = "";
            String name = "";
            Rect cardRect = new Rect(anchorRect);

            if (container != null) {
                container.getBoundsInScreen(cardRect);
                List<String> texts = new ArrayList<>();
                collectTexts(container, texts, 0);
                UpgradeRules.Card parsed = UpgradeRules.extractCardFromTexts(texts);
                if (parsed != null) {
                    id = parsed.customerId;
                    name = parsed.boldOrangeName;
                    isDist = parsed.isDistributor;
                    isRet = parsed.isRetailer;
                }
            }

            if (id.isEmpty() && anchorRect.height() > 0) {
                id = findCustomerIdNearY(allNodes, anchorRect.centerY());
                if (name.isEmpty()) {
                    name = findNameBelowY(allNodes, anchorRect.bottom, id);
                }
                if (container == null) {
                    container = AccessibilityTree.clickableAncestor(anchor, 10);
                    if (container == null) container = anchor;
                    container.getBoundsInScreen(cardRect);
                }
            }

            if (id.isEmpty() && !name.isEmpty()) {
                id = "NAME:" + name.trim().toUpperCase(Locale.ROOT).replaceAll("\\s+", " ");
            }
            if (id.isEmpty()) continue;
            if (cardRect.width() <= 0 || cardRect.height() <= 0) cardRect = anchorRect;

            String key = id + "|" + (isDist ? "D" : "R");
            if (!seen.add(key)) continue;

            cards.add(new CardInfo(id, name, isDist, isRet, cardRect, container));
        }

        Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
        return cards;
    }


    /**
     * Parses ALL visible customer card boxes in strict top-to-bottom order with ZERO SMR check
     * and ZERO (Dist)/(Retailer) requirement. Every clickable {@code cv_parent_view} box is returned.
     */
    public static List<CardInfo> parseAllCustomerBoxes(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        List<AccessibilityNodeInfo> allNodes = new ArrayList<>();
        collectNodes(root, allNodes, 0);

        List<CardInfo> cards = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();

        // Strategy 0: Every clickable cv_parent_view card block inside customer_list
        for (AccessibilityNodeInfo n : allNodes) {
            String viewId = n.getViewIdResourceName();
            if (viewId == null || !viewId.endsWith(VIEW_ID_CARD)) continue;
            List<String> texts = new ArrayList<>();
            collectTexts(n, texts, 0);
            UpgradeRules.Card parsed = UpgradeRules.extractAnyCustomerBox(texts);
            if (parsed == null) continue;
            Rect cardRect = new Rect();
            n.getBoundsInScreen(cardRect);
            String key = parsed.customerId;
            if (!seen.add(key)) continue;
            cards.add(new CardInfo(parsed.customerId, parsed.boldOrangeName,
                    parsed.isDistributor, parsed.isRetailer, cardRect, n));
        }

        if (!cards.isEmpty()) {
            Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
            return cards;
        }

        // Strategy 1: Fallback via Customer Id: labels -> clickable card container
        for (AccessibilityNodeInfo n : allNodes) {
            String t = AccessibilityTree.textOf(n).trim().toLowerCase(Locale.ROOT);
            if (!t.contains("customer id")) continue;
            AccessibilityNodeInfo container = AccessibilityTree.clickableAncestor(n, 10);
            if (container == null) container = findCardContainer(n);
            if (container == null) continue;
            List<String> texts = new ArrayList<>();
            collectTexts(container, texts, 0);
            UpgradeRules.Card parsed = UpgradeRules.extractAnyCustomerBox(texts);
            if (parsed == null) continue;
            Rect cardRect = new Rect();
            container.getBoundsInScreen(cardRect);
            if (!seen.add(parsed.customerId)) continue;
            cards.add(new CardInfo(parsed.customerId, parsed.boldOrangeName,
                    parsed.isDistributor, parsed.isRetailer, cardRect, container));
        }

        if (!cards.isEmpty()) {
            Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
            return cards;
        }

        return parseVisibleCards(root);
    }

    // --------------------------------------------------- Manual Boycott List (Permanent)

    public static void saveManualBoycott(Context context, String raw) {
        String clean = raw == null ? "" : raw.trim();
        prefs(context).edit().putString(KEY_MANUAL_BOYCOTT_RAW, clean).apply();
    }

    public static String manualBoycottRaw(Context context) {
        return prefs(context).getString(KEY_MANUAL_BOYCOTT_RAW, "");
    }

    public static Set<String> manualBoycottIds(Context context) {
        return UpgradeRules.parseManualBoycottText(manualBoycottRaw(context));
    }

    public static void clearManualBoycott(Context context) {
        prefs(context).edit().remove(KEY_MANUAL_BOYCOTT_RAW).apply();
    }

    public static String manualBoycottSummary(Context context) {
        Set<String> ids = manualBoycottIds(context);
        if (ids.isEmpty()) {
            return "Boycott List: Empty (har customer box click hoga; koi SMR filter nahi)";
        }
        StringBuilder sb = new StringBuilder("Boycott List (" + ids.size() + " IDs skipped): ");
        int i = 0;
        for (String id : ids) {
            if (i++ > 0) sb.append(", ");
            sb.append(id);
        }
        return sb.toString();
    }

    /** Exact clickable Show Retailers container from live capture (in.vasista.suprabhat:id/ll_show_retailers). */
    public static AccessibilityNodeInfo findShowRetailersContainer(AccessibilityNodeInfo root) {
        if (root == null) return null;
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        collectNodes(root, all, 0);
        for (AccessibilityNodeInfo n : all) {
            String vid = n.getViewIdResourceName();
            if (vid != null && vid.endsWith(VIEW_ID_SHOW_RETAILERS)) {
                return n;
            }
        }
        return null;
    }

    private static String findCustomerIdNearY(List<AccessibilityNodeInfo> allNodes, int targetCenterY) {
        int bestDist = 140;
        String bestId = "";
        for (int i = 0; i < allNodes.size(); i++) {
            AccessibilityNodeInfo n = allNodes.get(i);
            String t = AccessibilityTree.textOf(n).trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (!low.contains("customer id")) continue;

            Rect r = new Rect();
            n.getBoundsInScreen(r);
            int dist = Math.abs(r.centerY() - targetCenterY);
            if (dist > bestDist) continue;

            Matcher m = CUSTOMER_ID_INLINE.matcher(t);
            if (m.find() && m.group(1) != null && !m.group(1).trim().isEmpty()) {
                bestDist = dist;
                bestId = m.group(1).trim().toUpperCase(Locale.ROOT);
            } else {
                for (int j = i + 1; j < Math.min(allNodes.size(), i + 5); j++) {
                    String nextTxt = AccessibilityTree.textOf(allNodes.get(j)).trim();
                    if (!nextTxt.isEmpty() && !nextTxt.toLowerCase(Locale.ROOT).contains("delivery point")) {
                        Rect nr = new Rect();
                        allNodes.get(j).getBoundsInScreen(nr);
                        if (Math.abs(nr.centerY() - r.centerY()) < 60) {
                            bestDist = dist;
                            bestId = nextTxt.toUpperCase(Locale.ROOT);
                            break;
                        }
                    }
                }
            }
        }
        return bestId;
    }

    private static String findNameBelowY(List<AccessibilityNodeInfo> allNodes, int anchorBottomY, String customerId) {
        String best = "";
        int bestY = Integer.MAX_VALUE;
        for (AccessibilityNodeInfo n : allNodes) {
            String t = AccessibilityTree.textOf(n).trim();
            if (t.isEmpty()) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.equals("(dist)") || low.equals("(retailer)")
                    || low.contains("delivery point") || low.contains("customer id")
                    || low.startsWith("rtr_") || low.startsWith("route ")
                    || low.startsWith("s.o(") || low.startsWith("p.r")
                    || low.endsWith("[so]") || low.endsWith("[sd]")
                    || low.startsWith("total customers") || PHONE_LIKE.matcher(t).matches()) {
                continue;
            }
            if (customerId != null && !customerId.isEmpty() && t.equalsIgnoreCase(customerId)) continue;
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            if (r.top >= anchorBottomY - 12 && r.top <= anchorBottomY + 110 && r.top < bestY) {
                bestY = r.top;
                best = t;
            }
        }
        return best;
    }

    /** Section 5 Rule 2: Finds the filter dropdown (exact primSecLevelsSpinner ID first, then fallback). */
    public static Object[] findFilterDropdown(AccessibilityNodeInfo root) {
        if (root == null) return null;
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        collectNodes(root, all, 0);
        for (AccessibilityNodeInfo n : all) {
            String vid = n.getViewIdResourceName();
            if (vid != null && vid.endsWith(VIEW_ID_FILTER_SPINNER)) {
                List<String> texts = new ArrayList<>();
                collectTexts(n, texts, 0);
                String label = texts.isEmpty() ? AccessibilityTree.textOf(n) : texts.get(0);
                return new Object[]{n, label == null ? "" : label.trim()};
            }
        }

        AccessibilityNodeInfo allDist = AccessibilityTree.findExact(root, "All Distributors");
        if (allDist != null) return new Object[]{allDist, "All Distributors"};

        AccessibilityNodeInfo showRetailers = AccessibilityTree.findContaining(root, "show retailers");
        if (showRetailers == null) return null;
        Rect srRect = new Rect();
        showRetailers.getBoundsInScreen(srRect);
        if (srRect.width() <= 0 || srRect.height() <= 0) return null;

        AccessibilityNodeInfo best = null;
        for (AccessibilityNodeInfo n : all) {
            Rect r = new Rect();
            n.getBoundsInScreen(r);
            if (r.width() < 60 || r.height() <= 0) continue;
            boolean sameRow = Math.abs(r.centerY() - srRect.centerY()) < 120;
            boolean leftOf = r.right <= srRect.left + 40;
            if (!sameRow || !leftOf) continue;
            String t = AccessibilityTree.textOf(n);
            if (n.isClickable() || !t.isEmpty()) {
                if (best == null || (n.isClickable() && !best.isClickable())) {
                    best = n;
                }
            }
        }
        if (best == null) return null;
        List<String> texts = new ArrayList<>();
        collectTexts(best, texts, 0);
        String label = texts.isEmpty() ? AccessibilityTree.textOf(best) : texts.get(0);
        return new Object[]{best, label == null ? "" : label.trim()};
    }

    // --------------------------------------------------- Tier 1 Persistence

    public static boolean isLearned(Context context) {
        return prefs(context).getBoolean(KEY_LEARNED, false);
    }

    public static Set<String> permanentBlacklist(Context context) {
        Set<String> stored = prefs(context).getStringSet(KEY_BLACKLIST_IDS, Collections.emptySet());
        return stored == null ? Collections.emptySet() : new LinkedHashSet<>(stored);
    }

    public static int permDistributorScrolls(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_PERM_SCROLLS, 0));
    }

    public static void addBlacklistedIds(Context context, Set<String> ids) {
        if (ids == null || ids.isEmpty()) return;
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(ids);
        prefs(context).edit().putStringSet(KEY_BLACKLIST_IDS, merged).apply();
    }

    public static void saveLearnedBlueprint(Context context, Classification c, int permScrolls) {
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(c.allBlacklistedIds);
        prefs(context).edit()
                .putBoolean(KEY_LEARNED, true)
                .putStringSet(KEY_BLACKLIST_IDS, merged)
                .putInt(KEY_DIST_COUNT, Math.max(c.distributorIds.size(), prefs(context).getInt(KEY_DIST_COUNT, 0)))
                .putInt(KEY_PERM_SCROLLS, Math.max(0, permScrolls))
                .apply();
    }

    public static void resetDistributorHistory(Context context) {
        prefs(context).edit().clear().apply();
    }

    public static String statusSummary(Context context) {
        SharedPreferences p = prefs(context);
        if (!p.getBoolean(KEY_LEARNED, false)) {
            return "Tier 1 Permanent Blueprint: Not learned yet (auto-learns on next START)";
        }
        int dists = p.getInt(KEY_DIST_COUNT, 0);
        int blacklisted = permanentBlacklist(context).size();
        int scrolls = permDistributorScrolls(context);
        return "Tier 1 Permanent Blueprint: LEARNED · Distributors: " + dists
                + " · Blacklisted IDs: " + blacklisted + " · Top scrolls: " + scrolls;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // --------------------------------------------------------- Tree helpers

    private static AccessibilityNodeInfo findCardContainer(AccessibilityNodeInfo anchor) {
        AccessibilityNodeInfo cur = anchor;
        AccessibilityNodeInfo best = null;
        for (int hop = 0; cur != null && hop < 14; hop++) {
            String vid = cur.getViewIdResourceName();
            if (vid != null && vid.endsWith(VIEW_ID_CARD)) return cur;

            List<String> texts = new ArrayList<>();
            collectTexts(cur, texts, 0);
            int roleCount = 0;
            boolean hasId = false;
            for (String s : texts) {
                String low = s.trim().toLowerCase(Locale.ROOT);
                if (low.equals("(dist)") || low.equals("(retailer)")
                        || low.contains("delivery point (dist)") || low.contains("delivery point (retailer)")) {
                    roleCount++;
                }
                if (low.contains("customer id")) hasId = true;
            }
            if (roleCount > 1) break;
            if (roleCount == 1 && hasId) {
                best = cur;
                if (cur.isClickable()) return cur;
            }
            cur = cur.getParent();
        }
        return best;
    }

    private static void collectTexts(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 20 || out.size() > 120) return;
        String t = AccessibilityTree.textOf(node);
        if (!t.isEmpty()) out.add(t);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectTexts(node.getChild(i), out, depth + 1);
    }

    private static void collectNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out, int depth) {
        if (node == null || depth > 45 || out.size() > 2500) return;
        out.add(node);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectNodes(node.getChild(i), out, depth + 1);
    }
}
