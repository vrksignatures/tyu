package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;

/**
 * Bundled designer typography for Auriga (Syne display + Outfit geometric + Plus Jakarta Sans UI).
 */
final class AurigaFonts {
    private static Typeface brandBold;
    private static Typeface headingSemi;
    private static Typeface uiMedium;
    private static Typeface uiRegular;

    private AurigaFonts() {}

    static Typeface brand(Context c) {
        if (brandBold == null) brandBold = Typeface.createFromAsset(c.getAssets(), "fonts/EBGaramond.ttf");
        return brandBold;
    }

    static Typeface heading(Context c) {
        if (headingSemi == null) headingSemi = load(c, "fonts/Outfit.ttf", "'wght' 700", Typeface.BOLD);
        return headingSemi;
    }

    static Typeface medium(Context c) {
        if (uiMedium == null) uiMedium = load(c, "fonts/PlusJakartaSans.ttf", "'wght' 600", Typeface.NORMAL);
        return uiMedium;
    }

    static Typeface regular(Context c) {
        if (uiRegular == null) uiRegular = load(c, "fonts/PlusJakartaSans.ttf", "'wght' 400", Typeface.NORMAL);
        return uiRegular;
    }

    private static Typeface load(Context c, String assetPath, String variation, int fallbackStyle) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                return new Typeface.Builder(c.getAssets(), assetPath)
                        .setFontVariationSettings(variation)
                        .build();
            }
            return Typeface.createFromAsset(c.getAssets(), assetPath);
        } catch (Throwable ignored) {
            return Typeface.create("sans-serif", fallbackStyle);
        }
    }
}
